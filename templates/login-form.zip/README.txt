A Pen created at CodePen.io. You can find this one at https://codepen.io/j-w-v/pen/vxwJB.

 Playing with a login form layout. 